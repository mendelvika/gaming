# В этой папке должны быть favicon, apple-icon и др.
